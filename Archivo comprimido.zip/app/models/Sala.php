<?php 

	class Sala extends Eloquent 
	{

	}

?>	